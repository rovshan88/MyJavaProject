package Gucci;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

import java.sql.SQLOutput;

public class class1 {
    public static void main(String[] args) {

         byte minAge = 21;

         System.out.println("Legal min age to purchase Alcohol: "  +  minAge);

         int Salary = 100000;

                 System.out.println("Average salary QA: "+ Salary);

         long distanceML = 238900L;

                 System.out.println ("Distance between Earth and Moon in miles: "+ distanceML);

         double Debt$ = 57.1;


                 System.out.println ("The national debt of the United State in US dollars: "  + Debt$);

         float rate = 17.2f;
         char precent = '%';

                 System.out.println ("The interest rate in Chase bank: "+ rate + precent);

         boolean isyourgenderfemale = false;

                  System.out.println ("is your gender female? " + isyourgenderfemale);

         char firstInitial = 'R';
         char secondInitial = 'B';

                System.out.println("Name initial: "+firstInitial + secondInitial);











    }
}
